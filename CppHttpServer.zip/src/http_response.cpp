#include "http_response.hpp"

HTTPResponse::HTTPResponse() : status(StatusCodes::to_string(StatusCode::OK)) {}

void HTTPResponse::set_status(StatusCode code) {
    status = StatusCodes::to_string(code);
}

void HTTPResponse::add_header(const std::string& key, const std::string& value) {
    headers[key] = value;
}

void HTTPResponse::set_body(const std::string& b) {
    body = b;
}

std::string HTTPResponse::to_string() const {
    std::string response = "HTTP/1.1 " + status + "\r\n";
    for (const auto& pair : headers) {
        response += pair.first + ": " + pair.second + "\r\n";
    }
    response += "\r\n" + body;
    return response;
}
