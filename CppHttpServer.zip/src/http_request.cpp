#include "http_request.hpp"
#include <sstream>
#include <algorithm>

void HTTPRequest::parse(const char* request_data) {
    std::istringstream request_stream(request_data);
    std::string line;

    // Parse request line
    std::getline(request_stream, line);
    std::istringstream request_line(line);
    request_line >> method >> path;

    // Parse headers
    while (std::getline(request_stream, line) && line != "\r") {
        size_t colon = line.find(':');
        if (colon != std::string::npos) {
            std::string key = line.substr(0, colon);
            std::string value = line.substr(colon + 1);
            key.erase(std::remove(key.begin(), key.end(), ' '), key.end());
            value.erase(0, value.find_first_not_of(' '));
            value.erase(value.find_last_not_of(' ') + 1);
            headers[key] = value;
        }
    }

    // Parse body
    if (headers.find("Content-Length") != headers.end()) {
        size_t content_length = std::stoul(headers["Content-Length"]);
        body.resize(content_length);
        request_stream.read(&body[0], content_length);
    }
}
