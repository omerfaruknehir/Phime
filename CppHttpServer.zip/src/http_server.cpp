#include "http_server.hpp"
#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>

const int PORT = 8080;
const int BUFFER_SIZE = 1024;

HTTPServer::HTTPServer() : server_fd(-1) {}

void HTTPServer::start() {
    struct sockaddr_in address;
    int addrlen = sizeof(address);

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("Socket creation failed");
        return;
    }

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("Bind failed");
        return;
    }

    if (listen(server_fd, 3) < 0) {
        perror("Listen failed");
        return;
    }

    std::cout << "Server listening on port " << PORT << std::endl;

    while (true) {
        int client_socket;
        if ((client_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) < 0) {
            perror("Accept failed");
            continue;
        }

        handle_client(client_socket);
    }
}

void HTTPServer::add_route(const std::string& path, std::function<void(const HTTPRequest&, HTTPResponse&)> handler) {
    routes[path] = handler;
}

void HTTPServer::set_error_page(StatusCode code, const std::string& page_content) {
    error_pages[code] = page_content;
}

void HTTPServer::handle_client(int client_socket) {
    try {
        char buffer[BUFFER_SIZE] = {0};
        int valread = read(client_socket, buffer, BUFFER_SIZE);

        if (valread > 0) {
            HTTPRequest request;
            request.parse(buffer);

            HTTPResponse response;

            auto it = routes.find(request.path);
            if (it != routes.end()) {
                it->second(request, response);
            } else {
                response.set_status(StatusCode::NotFound);
                if (error_pages.find(StatusCode::NotFound) != error_pages.end()) {
                    response.set_body(error_pages[StatusCode::NotFound]);
                } else {
                    response.set_body("<h1>404 Not Found</h1>");
                }
            }

            std::string response_str = response.to_string();
            write(client_socket, response_str.c_str(), response_str.length());
        }
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;

        HTTPResponse response;
        response.set_status(StatusCode::InternalServerError);
        if (error_pages.find(StatusCode::InternalServerError) != error_pages.end()) {
            response.set_body(error_pages[StatusCode::InternalServerError]);
        } else {
            response.set_body("<h1>500 Internal Server Error</h1>");
        }

        std::string response_str = response.to_string();
        write(client_socket, response_str.c_str(), response_str.length());
    }

    close(client_socket);
}
