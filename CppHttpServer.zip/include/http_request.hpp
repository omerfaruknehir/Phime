#ifndef HTTP_REQUEST_HPP
#define HTTP_REQUEST_HPP

#include <string>
#include <map>

class HTTPRequest {
public:
    std::string method;
    std::string path;
    std::map<std::string, std::string> headers;
    std::string body;

    void parse(const char* request_data);
};

#endif // HTTP_REQUEST_HPP
