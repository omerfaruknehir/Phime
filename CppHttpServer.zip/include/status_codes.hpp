#ifndef STATUS_CODES_HPP
#define STATUS_CODES_HPP

#include <string>

enum class StatusCode {
    OK = 200,
    Created = 201,
    Accepted = 202,
    NoContent = 204,
    MovedPermanently = 301,
    Found = 302,
    NotModified = 304,
    BadRequest = 400,
    Unauthorized = 401,
    Forbidden = 403,
    NotFound = 404,
    InternalServerError = 500,
    NotImplemented = 501,
    BadGateway = 502,
    ServiceUnavailable = 503,
    // Add more status codes as needed
};

class StatusCodes {
public:
    static std::string to_string(StatusCode code) {
        switch (code) {
            case StatusCode::OK:
                return "200 OK";
            case StatusCode::Created:
                return "201 Created";
            case StatusCode::Accepted:
                return "202 Accepted";
            case StatusCode::NoContent:
                return "204 No Content";
            case StatusCode::MovedPermanently:
                return "301 Moved Permanently";
            case StatusCode::Found:
                return "302 Found";
            case StatusCode::NotModified:
                return "304 Not Modified";
            case StatusCode::BadRequest:
                return "400 Bad Request";
            case StatusCode::Unauthorized:
                return "401 Unauthorized";
            case StatusCode::Forbidden:
                return "403 Forbidden";
            case StatusCode::NotFound:
                return "404 Not Found";
            case StatusCode::InternalServerError:
                return "500 Internal Server Error";
            case StatusCode::NotImplemented:
                return "501 Not Implemented";
            case StatusCode::BadGateway:
                return "502 Bad Gateway";
            case StatusCode::ServiceUnavailable:
                return "503 Service Unavailable";
            // Add more status code strings as needed
            default:
                return "500 Internal Server Error";
        }
    }
};

#endif // STATUS_CODES_HPP
