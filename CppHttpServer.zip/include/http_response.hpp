#ifndef HTTP_RESPONSE_HPP
#define HTTP_RESPONSE_HPP

#include <string>
#include <map>
#include "status_codes.hpp"

class HTTPResponse {
public:
    HTTPResponse();

    void set_status(StatusCode code);
    void add_header(const std::string& key, const std::string& value);
    void set_body(const std::string& b);
    std::string to_string() const;

private:
    std::string status;
    std::map<std::string, std::string> headers;
    std::string body;
};

#endif // HTTP_RESPONSE_HPP
