#ifndef HTTP_SERVER_HPP
#define HTTP_SERVER_HPP

#include <functional>
#include <map>
#include <string>
#include "http_request.hpp"
#include "http_response.hpp"
#include "status_codes.hpp"

class HTTPServer {
public:
    HTTPServer();
    void start();
    void add_route(const std::string& path, std::function<void(const HTTPRequest&, HTTPResponse&)> handler);
    void set_error_page(StatusCode code, const std::string& page_content);

private:
    int server_fd;
    std::map<std::string, std::function<void(const HTTPRequest&, HTTPResponse&)>> routes;
    std::map<StatusCode, std::string> error_pages;

    void handle_client(int client_socket);
};

#endif // HTTP_SERVER_HPP
