#include <iostream>
#include "http_server.hpp"
#include "http_request.hpp"
#include "http_response.hpp"
#include "status_codes.hpp"

void hello_handler(const HTTPRequest& request, HTTPResponse& response) {
    response.set_status(StatusCode::OK);
    response.add_header("Content-Type", "text/html");
    response.set_body("<h1>Hello, HTTP Server!</h1>");
}

void just_error_handler(const HTTPRequest& request, HTTPResponse& response) {
    throw std::runtime_error("Intentional error for testing");
}

int main() {
    HTTPServer server;
    server.add_route("/", hello_handler);
    server.add_route("/error", just_error_handler);
    server.set_error_page(StatusCode::NotFound, "<h1>Custom 404 Page</h1>");
    server.set_error_page(StatusCode::InternalServerError, "<h1>Custom 500 Internal Server Error Page</h1>");
    server.start();
    return 0;
}
